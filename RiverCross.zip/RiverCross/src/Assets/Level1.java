package Assets;

public class Level1 {

}
